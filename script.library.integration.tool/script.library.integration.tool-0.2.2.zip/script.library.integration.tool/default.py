#!/usr/bin/python
# -*- coding: utf-8 -*-
''' main entry point for addon '''

from resources.lib.main import Main

Main()
